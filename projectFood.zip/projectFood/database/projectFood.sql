-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Dec 21, 2021 at 11:53 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projectFood`
--
CREATE DATABASE IF NOT EXISTS `projectFood` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `projectFood`;

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `customerName` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `nameOfRestaurant` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `User_Name` varchar(255) NOT NULL,
  `email` varchar(257) DEFAULT NULL,
  `Password` varchar(258) DEFAULT NULL,
  `Phone_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `id` int(11) NOT NULL,
  `nameOfFood` varchar(255) DEFAULT NULL,
  `Data` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `nameOfRestaurant` varchar(255) DEFAULT NULL,
  `countt` float(100,2) DEFAULT NULL,
  `im1` varchar(255) DEFAULT NULL,
  `im2` varchar(255) DEFAULT NULL,
  `im3` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`id`, `nameOfFood`, `Data`, `img`, `nameOfRestaurant`, `countt`, `im1`, `im2`, `im3`) VALUES
(1, 'Share Box', 'Pick 2 sandwiches from Big Mac (beef/chicken) and McChicken + 2 sandwiches from Beefburger, cheeseburger and Chicken MacDo + 2 regular fries + 1 liter Coke', 'mc1.jpg', 'macdonald', 124.99, 'mc1.jpg', 'mc2.jfif', 'mc3.png'),
(2, 'Big Tasty', 'Juicy beef patty smothered in three extraordinary slices of Emmental cheese and topped with sliced tomato, shredded lettuce, onions and that special Big Tasty sauce', 'mc2.jpg', 'macdonald', 68.49, 'mc1.jpg', 'mc2.jfif', 'mc3.png'),
(3, 'Big MaGrand Share Boxc', 'Two beef patties, that unbeatably tasty Big Mac sauce, melting signature cheese, crisp shredded lettuce, onions, pickles and a bun in the middle all between a toasted sesame seed bun', 'mc3.jpg', 'macdonald', 42.50, 'mc1.jpg', 'mc2.jfif', 'mc3.png'),
(4, 'Mix 2 Meal', 'Pick two! Choose among the tasty Cheeseburger, the delicious Chicken MacDo or the juicy Beefburger + Small Fries + Regular Drink', 'mc4.jpg', 'macdonald', 44.00, 'mc1.jpg', 'mc2.jfif', 'mc3.png'),
(5, 'Double Big Tasty', 'Two juicy beef patties smothered between slices of Emmental cheese, topped with sliced tomato, shredded lettuce, onions and that special Big Tasty sauce', 'mc5.jpg', 'macdonald', 84.00, 'mc1.jpg', 'mc2.jfif', 'mc3.png'),
(6, 'Chocolate Fudge Sundae', 'Vanilla soft serve, smothered in chocolaty fudge sauce', 'mc6.jpg', 'macdonald', 16.50, 'mc1.jpg', 'mc2.jfif', 'mc3.png'),
(7, 'Chicken Mac', 'A delicious combination of breaded chicken patties, crisp lettuce, melting cheese, onions, pickles, and our special sauce, all framed between a toasted sesame seed bun', 'mc7.jpg', 'macdonald', 57.00, 'mc1.jpg', 'mc2.jfif', 'mc3.png'),
(8, 'McFries', 'Get them while they are hot. Our legendary super-tasty French fries are the perfect side to any meal. We only use the highest quality potatoes to create those delicious strands of crispy fluffy fries you love', 'mc8.jpg', 'macdonald', 13.00, 'mc1.jpg', 'mc2.jfif', 'mc3.png'),
(9, 'Grand Share Box', 'Pick 2 sandwiches from the juicy Big Tasty (beef/chicken) and delicious Grand Chicken (premier/spicy) + 2 sandwiches from Beefburger, cheeseburger and Chicken MACDO + 2 regular fries + 1 liter Coke', 'mc9.jpg', 'macdonald', 179.00, 'mc1.jpg', 'mc2.jfif', 'mc3.png'),
(10, 'Dinner Twist', '3pcs chicken + Twister Sandwich+ Coleslaw + Fries + Pepsi + Bun', 'Dinner Twist.webp', 'KFC', 106.00, 'Dipping Box (1).jpg', 'Dipping Box (2).jpg', 'Dipping Box (3).jpg'),
(11, 'Shrimp Box', '7 pcs shrimps + small Coleslaw + Small fries + Rice + Bun + 2 Cocktail sauces + Drink', 'Shrimp Box.webp', 'KFC', 106.00, 'Dipping Box (1).jpg', 'Dipping Box (2).jpg', 'Dipping Box (3).jpg'),
(12, 'Mighty Tower Combo', 'MghtyTower Sandwich + Normal Fries + Drink', 'imagesMighty Tower Combo.webp', 'KFC', 92.00, 'Dipping Box (1).jpg', 'Dipping Box (2).jpg', 'Dipping Box (3).jpg'),
(13, 'Mighty Tower Box', 'Måghty Tower Sandwich + 1 Pc Chicken + Large Rice + small Coleslaw + Drink', 'Mighty Tower Box.webp', 'KFC', 110.00, 'Dipping Box (1).jpg', 'Dipping Box (2).jpg', 'Dipping Box (3).jpg'),
(14, 'Charger Sandwich', '1 Sandwich', 'Charger Sandwich.webp', 'KFC', 42.00, 'Dipping Box (1).jpg', 'Dipping Box (2).jpg', 'Dipping Box (3).jpg'),
(15, 'Charger Combo', 'Sandwich + Fries + Drink', 'Charger Combo.webp', 'KFC', 56.00, 'Dipping Box (1).jpg', 'Dipping Box (2).jpg', 'Dipping Box (3).jpg'),
(16, 'Charger Box', 'Sandwich + Drink + 1 COB + Rice + Colelslaw', 'Charger Box.webp', 'KFC', 71.00, 'Dipping Box (1).jpg', 'Dipping Box (2).jpg', 'Dipping Box (3).jpg'),
(17, 'Monster Combo', 'Sandwich + Fries + Drink', 'Monster Combo.webp', 'KFC', 101.00, 'Dipping Box (1).jpg', 'Dipping Box (2).jpg', 'Dipping Box (3).jpg'),
(18, 'Monster Box', 'Sandwich + Drink + 1 COB + Rice + Colelslaw', 'Monster Box.webp', 'KFC', 117.00, 'Dipping Box (1).jpg', 'Dipping Box (2).jpg', 'Dipping Box (3).jpg'),
(19, 'Dipping Box', '3 Coleslaw + 2 Strips + Fries + 1 Coleslaw + 1 Pepsi + 2 Sauces', 'Dipping Box.webp', 'KFC', 102.00, 'Dipping Box (1).jpg', 'Dipping Box (2).jpg', 'Dipping Box (3).jpg'),
(20, 'Big Filler Box1 Filler Sandwich+ 1 pc Chicken + 1 Large Rice + 1 small coleslaw + 1 Drink', '1 Filler Sandwich+ 1 pc Chicken + 1 Large Rice + 1 small coleslaw + 1 Drink', 'Big Filler.webp', 'KFC', 109.00, 'Dipping Box (1).jpg', 'Dipping Box (2).jpg', 'Dipping Box (3).jpg'),
(21, 'Mighty Plus', 'Mighty Zinger Sandwich + Rizo + Coleslaw+ Drink', 'Mighty Plus.webp', 'KFC', 85.00, 'Dipping Box (1).jpg', 'Dipping Box (2).jpg', 'Dipping Box (3).jpg'),
(22, 'Cheddar Cheese', 'Our pizza sauce combined with authentic Cheddar cheese and Mozzarella.', 'paj1.jpg', 'Papa Johns Pizza', 70.00, 'papa johns1.jpg', 'papa johns2.jpg', 'papa johns3.jpg'),
(23, 'Chicken Ranch', 'Grilled chicken, tomato, fresh mushroom with ranch sauce', 'paj2.jpg', 'Papa Johns Pizza', 70.00, 'papa johns1.jpg', 'papa johns2.jpg', 'papa johns3.jpg'),
(24, 'Pepperoni', 'Loaded with pepperoni and extra mozzarella cheese', 'paj3.jpg', 'Papa Johns Pizza', 55.00, 'papa johns1.jpg', 'papa johns2.jpg', 'papa johns3.jpg'),
(25, 'Smoky Cheese', 'Smoked veal, smoked cheese, cheddar, gouda, onion with creamy sauce', 'paj4.jpg', 'Papa Johns Pizza', 70.00, 'papa johns1.jpg', 'papa johns2.jpg', 'papa johns3.jpg'),
(26, 'Super Papas', 'Pepperoni, Italian sausage, smoked veal, fresh mushroom, onion, green pepper and black olives', 'paj5.jpg', 'Papa Johns Pizza', 65.00, 'papa johns1.jpg', 'papa johns2.jpg', 'papa johns3.jpg'),
(27, 'Margherita', 'Mozzarella cheese and pizza sauce', 'paj6.jpg', 'Papa Johns Pizza', 42.00, 'papa johns1.jpg', 'papa johns2.jpg', 'papa johns3.jpg'),
(28, 'Chicken BBQ', 'Grilled chicken, onion, fresh mushroom and BBQ sauce drizzled on top', 'paj7.jpg', 'Papa Johns Pizza', 65.00, 'papa johns1.jpg', 'papa johns2.jpg', 'papa johns3.jpg'),
(29, 'Chicken Wings', 'Savory wings baked to the bone served with your choice from 3 flavors grilled, spicy or BBQ and served with BBQ sauce', 'paj8.jpg', 'Papa Johns Pizza', 40.00, 'papa johns1.jpg', 'papa johns2.jpg', 'papa johns3.jpg'),
(30, 'Super Papas  Chicken BBQ', 'With garden special and margherita', 'paj9.jpg', 'Papa Johns Pizza', 185.00, 'papa johns1.jpg', 'papa johns2.jpg', 'papa johns3.jpg'),
(31, 'Big Boss', '2 chicken breasts, beef bacon, 2 cheese slices, BBQ, lettuce, mayonnaise and bread with sesame', 'Kaf1.jpg', 'Kansas Fried Chicken', 59.50, 'kanses1.jpg', 'kanses2.jpg', 'kanses3.jpg'),
(32, '321 Mix', '2 large chicken pieces, 1 small chicken piece with special marination, rice, bread, 2 slices of crispy chicken', 'Kaf2.jpg', 'Kansas Fried Chicken', 95.00, 'kanses1.jpg', 'kanses2.jpg', 'kanses3.jpg'),
(33, 'Arizo', 'Rice with special Kansas spices with crispy chicken piece, hot or BBQ sauce', 'Kaf3.jpg', 'Kansas Fried Chicken', 29.50, 'kanses1.jpg', 'kanses2.jpg', 'kanses3.jpg'),
(34, 'Dinner Meal', '2 large fried chicken pieces, 1 small fried chicken piece covered with Kansas special spices', 'Kaf4.jpg', 'Kansas Fried Chicken', 82.00, 'kanses1.jpg', 'kanses2.jpg', 'kanses3.jpg'),
(35, '8 Pieces', '4 large pieces, 4 small pieces, family fries, large coleslaw, 4 bread and large drink', 'Kaf5.jpg', 'Kansas Fried Chicken', 189.00, 'kanses1.jpg', 'kanses2.jpg', 'kanses3.jpg'),
(36, 'Lunch Meal', '1 large chicken piece, 1 small chicken piece covered with Kansas special spices', 'Kaf6.jpg', 'Kansas Fried Chicken', 60.00, 'kanses1.jpg', 'kanses2.jpg', 'kanses3.jpg'),
(37, 'Crispy Saver', 'Crispy chicken breast strips with special spices, 5 pieces combo served with fries & coleslaw', 'Kaf7.jpg', 'Kansas fried Chicken', 82.00, 'kanses1.jpg', 'kanses2.jpg', 'kanses3.jpg'),
(38, '12 Pieces', '6 large pieces, 6 small pieces, family fries, large coleslaw, 6 bread and large drink', 'Kaf8.jpg', 'Kansas Fried Chicken', 245.00, 'kanses1.jpg', 'kanses2.jpg', 'kanses3.jpg'),
(39, 'Kansas Wrap', '2 crispy chicken breast strips, tomatoes, mayonnaise with pepper, lettuce and tortilla bread', 'Kaf9.jpg', 'Kansas Fried Chicken', 34.50, 'kanses1.jpg', 'kanses2.jpg', 'kanses3.jpg'),
(40, 'Bacon Mushroom Jack', 'Beef bacon with fresh sauteed mushroom, cheddar cheese and creamy mayonnaise', 'buf1.jpg', 'Buffalo Burger', 74.56, 'buffalo1.jpg', 'buffalo2.jpg', 'buffalo3.jpg'),
(41, 'Charbroiled BBQ', 'Grilled burger topped with sweet onion, BBQ sauce, creamy Charbroiled sauce and Swiss cheese', 'buf2.jpg', 'Buffalo Burger', 60.53, 'buffalo1.jpg', 'buffalo2.jpg', 'buffalo3.jpg'),
(42, 'Old School', 'Pure beef burger patty, topped with our signature Buffalo sauce and cheddar cheese', 'buf3.jpg', 'Buffalo Burger', 56.14, 'buffalo1.jpg', 'buffalo2.jpg', 'buffalo3.jpg'),
(43, 'Hitchhiker', 'Crispy mini mozzarella sticks, loaded with ketchup and mustard drops, beef bacon and creamy Buffalo sauce on top of our pure beef burger patty', 'buf4.jpg', 'Buffalo Burger', 74.56, 'buffalo1.jpg', 'buffalo2.jpg', 'buffalo3.jpg'),
(44, 'Shitake Mushroom', 'Sauteed mushroom, cheddar cheese and creamy mayonnaise spread on top of our pure beef burger patty', 'buf5.jpg', 'Buffalo Burger', 64.91, 'buffalo1.jpg', 'buffalo2.jpg', 'buffalo3.jpg'),
(45, 'Cholos', 'Pickled sliced jalapenos, Buffalo sauce and cheddar cheese on top of our pure beef burger patty', 'buf6.jpg', 'Buffalo Burger', 56.14, 'buffalo1.jpg', 'buffalo2.jpg', 'buffalo3.jpg'),
(46, 'X-Urban', 'A juicy burger patty with cheddar cheese, beef bacon, crispy onion rings with BBQ sauce and caramelized onions', 'buf7.jpg', 'Buffalo Burger', 69.30, 'buffalo1.jpg', 'buffalo2.jpg', 'buffalo3.jpg'),
(47, 'Double Diggler', 'A high stack of crispy chicken strips in three layers of buns with two layers of cheddar cheese, pickles, tomatoes, lettuce and malbec sauce', 'buf8.jpg', 'Buffalo Burger', 69.30, 'buffalo1.jpg', 'buffalo2.jpg', 'buffalo3.jpg'),
(48, 'Cheesy Fries', 'Served with thousand island sauce', 'buf9.jpg', 'Buffalo Burger', 35.09, 'buffalo1.jpg', 'buffalo2.jpg', 'buffalo3.jpg'),
(49, 'Choose Any 3 Pizzas', 'Served with 1 liter coca cola and 1 salad', 'pizm1.jpg', 'pizza master', 153.51, 'pizza-Master1.jpg', 'pizza-Master2.jpg', 'pizza-Master3.jpg'),
(50, 'Choose Any 2 Pizzas', 'Served with 1 liter coca cola and 1 salad', 'pizm2.jpg', 'pizza master', 140.35, 'pizza-Master1.jpg', 'pizza-Master2.jpg', 'pizza-Master3.jpg'),
(51, 'Chicken Ranch', 'Chicken, green pepper, onions, jalapeno, ranch sauce and mozzarella', 'pizm3.jpg', 'pizza master', 71.05, 'pizza-Master1.jpg', 'pizza-Master2.jpg', 'pizza-Master3.jpg'),
(52, 'Chicken BBQ', 'Chicken, green pepper, onions, BBQ sauce, mushroom and mozzarella', 'pizm4.jpg', 'pizza master', 140.35, 'pizza-Master1.jpg', 'pizza-Master2.jpg', 'pizza-Master3.jpg'),
(53, 'Cheese Lovers', '3 kinds of cheese', 'pizm5.jpg', 'pizza master', 71.93, 'pizza-Master1.jpg', 'pizza-Master2.jpg', 'pizza-Master3.jpg'),
(54, 'Super Supreme', 'Salami, pepperoni, beef, mushroom, green pepper, olives, onions and mozzarella, pizza sauce', 'pizm6.jpg', 'pizza master', 67.54, 'pizza-Master1.jpg', 'pizza-Master2.jpg', 'pizza-Master3.jpg'),
(55, 'Master Pizza', 'Salami, pepperoni, hot dog, black olives, pizza sauce, mozzarella and mushroom', 'pizm7.jpg', 'pizza master', 71.05, 'pizza-Master1.jpg', 'pizza-Master2.jpg', 'pizza-Master3.jpg'),
(56, 'Pepperoni Jalapeno', 'Pepperoni, green pepper, onions, jalapeno, pizza sauce and mozzarella', 'pizm8.jpg', 'pizza master', 59.65, 'pizza-Master1.jpg', 'pizza-Master2.jpg', 'pizza-Master3.jpg'),
(57, 'Hot Dog', 'Hot dog, green pepper, pizza sauce, black olive, mozzarella', 'pizm9.jpg', 'pizza master', 58.77, 'pizza-Master1.jpg', 'pizza-Master2.jpg', 'pizza-Master3.jpg'),
(58, 'Juicy Lucy', 'Fried chicken piece stuffed American cheddar cheese, ranch sauce, fried cream cheese bites and lettuce', 'chfi1.jpg', 'CHICKEN FILA', 64.95, 'chicken filla1.jpg', 'chicken filla2.jpg', 'chicken filla3.jpg'),
(59, 'The Original Fil', 'Fried chicken pieces stuffed American cheddar cheese, cheese sauce, honey mustard sauce, lettuce', 'chfi2.jpg', 'CHICKEN FILA', 59.95, 'chicken filla1.jpg', 'chicken filla2.jpg', 'chicken filla3.jpg'),
(60, 'Cowboy BBQ', 'Fried chicken piece stuffed American cheddar cheese, BBQ sauce, onion rings, smoked turkey, cheese sauce and lettuce', 'chfi3.jpg', 'CHICKEN FILA', 64.95, 'chicken filla1.jpg', 'chicken filla2.jpg', 'chicken filla3.jpg'),
(61, 'The American Fil', 'Fried chicken piece stuffed American cheddar cheese, American salty pickles sauce, beef bacon, lettuce', 'chfi4.jpg', 'CHICKEN FILA', 64.95, 'chicken filla1.jpg', 'chicken filla2.jpg', 'chicken filla3.jpg'),
(62, 'Spicy Buffalo Juicy Lucy', 'Fried buffalo chicken pieces stuffed American cheddar cheese dipped in spicy buffalo sauce, fried cream cheese bites, ranch sauce, jalapenos, lettuce', 'chfi5.jpg', 'CHICKEN FILA', 64.95, 'chicken filla1.jpg', 'chicken filla2.jpg', 'chicken filla3.jpg'),
(63, 'Hot Rings', 'Fried chicken pieces stuffed American cheddar cheese, hell sauce, sweet chili mayo sauce, onion rings, lettuce', 'chfi6.jpg', 'CHICKEN FILA', 59.95, 'chicken filla1.jpg', 'chicken filla2.jpg', 'chicken filla3.jpg'),
(64, 'The Mexican Fil', 'Fried chicken piece stuffed American cheddar cheese, colored pepper, spicy mayonnaise, cheese sauce, doritos, lettuce', 'chfi7.jpg', 'CHICKEN FILA', 64.95, 'chicken filla1.jpg', 'chicken filla2.jpg', 'chicken filla3.jpg'),
(65, 'The Italian Fil', '2 fried chicken pieces stuffed American cheddar cheese, tomato pizza sauce, mozzarella cheese, pepperoni, ranch sauce, lettuce', 'chfi8.jpg', 'CHICKEN FILA', 89.95, 'chicken filla1.jpg', 'chicken filla2.jpg', 'chicken filla3.jpg'),
(66, 'Cordon Bleu Fries', 'French fries, chicken strips, smoked turkey, cheese sauce, ranch sauce', 'chfi9.jpg', 'CHICKEN FILA', 44.95, 'chicken filla1.jpg', 'chicken filla2.jpg', 'chicken filla3.jpg'),
(67, 'Big Star', 'Koshary, Desserts, Oriental', 'sah1.jpg', 'Sayed Hanafy', 24.00, 'sayed hanfy1.png', 'sayed hanfy2.jfif', 'sayed hanfy3.jpg'),
(68, 'Star Plus', 'Koshary, Desserts, Oriental', 'sah2.jpg', 'Sayed Hanafy', 18.00, 'sayed hanfy1.png', 'sayed hanfy2.jfif', 'sayed hanfy3.jpg'),
(69, 'Super Star', 'Koshary, Desserts, Oriental', 'sah3.jpg', 'Sayed Hanafy', 27.00, 'sayed hanfy1.png', 'sayed hanfy2.jfif', 'sayed hanfy3.jpg'),
(70, 'Pasta with Meat', 'Koshary, Desserts, Oriental', 'sah4.jpg', 'Sayed Hanafy', 23.00, 'sayed hanfy1.png', 'sayed hanfy2.jfif', 'sayed hanfy3.jpg'),
(71, 'Small Rice Pudding', 'Koshary, Desserts, Oriental', 'sah5.jpg', 'Sayed Hanafy', 11.00, 'sayed hanfy1.png', 'sayed hanfy2.jfif', 'sayed hanfy3.jpg'),
(72, 'Crispy Toast', 'Koshary, Desserts, Oriental', 'sah6.jpg', 'Sayed Hanafy', 5.00, 'sayed hanfy1.png', 'sayed hanfy2.jfif', 'sayed hanfy3.jpg'),
(73, 'Pepsi', 'Koshary, Desserts, Oriental', 'sah7.jpg', 'Sayed Hanafy', 7.00, 'sayed hanfy1.png', 'sayed hanfy2.jfif', 'sayed hanfy3.jpg'),
(74, 'Small Box', 'Koshary, Desserts, Oriental', 'sah8.jpg', 'Sayed Hanafy', 10.00, 'sayed hanfy1.png', 'sayed hanfy2.jfif', 'sayed hanfy3.jpg'),
(75, 'Mega Foil', 'Koshary, Desserts, Oriental', 'sah9.jpg', 'Sayed Hanafy', 20.00, 'sayed hanfy1.png', 'sayed hanfy2.jfif', 'sayed hanfy3.jpg'),
(76, 'Flat White', 'A pure full-flavored coffee with a unique smooth creamy texture fuller than creamier than a cappuccino for real coffee lovers', 'costcaf1.jpg', 'costa coffee', 40.99, 'costa1.jpg', 'costa2.png', 'Costa-Coffee-.jpg'),
(77, 'Latte', 'Rich costa espresso poured over steamed milk', 'costcaf2.jpg', 'costa coffee', 37.00, 'costa1.jpg', 'costa2.png', 'Costa-Coffee-.jpg'),
(78, 'Triple Cheese', 'Cheddar cheese, mozzarella cheese, emmental cheese, mushroom and chopped onion, served in a rustic white baguette, served hot', 'costcaf3.jpg', 'costa coffee', 54.00, 'costa1.jpg', 'costa2.png', 'Costa-Coffee-.jpg'),
(79, 'Cappuccino', 'Coffee combining espresso with steamed , frothy Milk', 'costcaf4.jpg', 'costa coffee', 37.00, 'costa1.jpg', 'costa2.png', 'Costa-Coffee-.jpg'),
(80, 'Americano', 'The classic costa espresso served with hot water', 'costcaf5.jpg', 'costa coffee', 33.00, 'costa1.jpg', 'costa2.png', 'Costa-Coffee-.jpg'),
(81, 'Classic Corto', 'A rich double shot of full-bodied coffee served short with velvety milk', 'costcaf6.jpg', 'costa coffee', 34.00, 'costa1.jpg', 'costa2.png', 'Costa-Coffee-.jpg'),
(82, 'Caramel Corto', 'A rich double shot of full-bodied coffee served short with milk and caramel', 'costcaf7.jpg', 'costa coffee', 34.00, 'costa1.jpg', 'costa2.png', 'Costa-Coffee-.jpg'),
(83, 'Espresso', 'A short strong and black coffee with no milk', 'costcaf8.jpg', 'costa coffee', 22.00, 'costa1.jpg', 'costa2.png', 'Costa-Coffee-.jpg'),
(84, 'Iced Flat White', 'A pure full-flavored coffee with a unique smooth creamy texture fuller than creamier than a cappuccino for real coffee lovers our rich mocha Italia coffee is shaken by hand with ice to keep every last drop of flavor', 'costcaf9.jpg', 'costa coffee', 36.00, 'costa1.jpg', 'costa2.png', 'Costa-Coffee-.jpg'),
(85, 'Cappuccino', 'Coffee & Tea, Bakery and Cakes, Beverages', 'starbucks1.jpg', 'starbucks', 35.00, 'starbuks1.jpg', 'starbuks2.jpg', 'starbuks3.jpg'),
(86, 'Double Caramel', 'Coffee & Tea, Bakery and Cakes, Beverages', 'starbucks2.jpg', 'starbucks', 55.00, 'starbuks1.jpg', 'starbuks2.jpg', 'starbuks3.jpg'),
(87, 'Double Chocolate Cream Chip', 'Coffee & Tea, Bakery and Cakes, Beverages', 'starbucks3.jpg', 'starbucks', 55.00, 'starbuks1.jpg', 'starbuks2.jpg', 'starbuks3.jpg'),
(88, 'Espresso', 'Coffee & Tea, Bakery and Cakes, Beverages', 'starbucks4.jpg', 'starbucks', 20.00, 'starbuks1.jpg', 'starbuks2.jpg', 'starbuks3.jpg'),
(89, 'White Mocha', 'Coffee & Tea, Bakery and Cakes, Beverages', 'starbucks5.jpg', 'starbucks', 50.00, 'starbuks1.jpg', 'starbuks2.jpg', 'starbuks3.jpg'),
(90, 'Iced Latte', 'Coffee & Tea, Bakery and Cakes, Beverages', 'starbucks6.jpg', 'starbucks', 35.00, 'starbuks1.jpg', 'starbuks2.jpg', 'starbuks3.jpg'),
(91, 'Iced White Caffe Mocha', 'Coffee & Tea, Bakery and Cakes, Beverages', 'starbucks7.jpg', 'starbucks', 40.00, 'starbuks1.jpg', 'starbuks2.jpg', 'starbuks3.jpg'),
(92, 'Matcha', 'Coffee & Tea, Bakery and Cakes, Beverages', 'starbucks8.jpg', 'starbucks', 50.00, 'starbuks1.jpg', 'starbuks2.jpg', 'starbuks3.jpg'),
(93, 'Turkey & Cheese Croissant', 'Coffee & Tea, Bakery and Cakes, Beverages', 'starbucks9.jpg', 'starbucks', 31.00, 'starbuks1.jpg', 'starbuks2.jpg', 'starbuks3.jpg'),
(94, 'Mushroom and Swiss Burger', 'Chargrilled all-beef patty, topped with melted Swiss cheese and finished with our unique mushroom sauce on our special Hardees bun', 'hardes1.jpg', 'hardees', 48.00, 'Hardees1.jpg', 'Hardees2.jpg', 'Hardees3.jpg'),
(95, 'Super Star', 'Two chargrilled all-beef patties topped with American cheese, dill pickles, fresh tomatoes, onions and lettuce on our special Hardees', 'hardes2.jpg', 'hardees', 75.00, 'Hardees1.jpg', 'Hardees2.jpg', 'Hardees3.jpg'),
(96, 'Curly Fries', 'Premium quality potato cut into curls and cooked to golden crisp', 'hardes3.jpg', 'hardees', 28.00, 'Hardees1.jpg', 'Hardees2.jpg', 'Hardees3.jpg'),
(97, 'Chicken Wrapper', 'Chicken tender, topped with American cheese, lettuce and mayonnaise, served in tortilla bread', 'hardes4.jpg', 'hardees', 39.00, 'Hardees1.jpg', 'Hardees2.jpg', 'Hardees3.jpg'),
(98, 'Cordon Bleu', 'Crispy breaded, mayonnaise, sliced turkey, chicken fillet, tomato, lettuce, Swiss cheese', 'hardes5.jpg', 'hardees', 69.50, 'Hardees1.jpg', 'Hardees2.jpg', 'Hardees3.jpg'),
(99, 'Mushroom and Swiss Angus ThickBurger', 'Chargrilled premium 100% Angus beef, covered in our unique mushroom sauce and topped with melted Swiss cheese and special black pepper may. on our famous brioche bun', 'hardes6.jpg', 'hardees', 81.00, 'Hardees1.jpg', 'Hardees2.jpg', 'Hardees3.jpg'),
(100, 'Roast Beef and Cheddar', 'Slices of roast beef topped with melted cheddar cheese in our freshly baked braided bun', 'hardes7.jpg', 'hardees', 65.00, 'Hardees1.jpg', 'Hardees2.jpg', 'Hardees3.jpg'),
(101, 'Mighty Tender', '5 tender pieces (boneless chicken), fries, drink, 2 sauce and bun', 'hardes8.jpg', 'hardees', 82.50, 'Hardees1.jpg', 'Hardees2.jpg', 'Hardees3.jpg'),
(102, 'Chicken Fillet', 'Our crispy breaded 100% all-white meat chicken fillet on a layer of lettuce and mayonnaise on our special Hardees bun', 'hardes9.jpg', 'hardees', 55.00, 'Hardees1.jpg', 'Hardees2.jpg', 'Hardees3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `restaurants`
--

CREATE TABLE `restaurants` (
  `nameOfRestaurant` varchar(255) NOT NULL,
  `Data` varchar(255) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `restaurants`
--

INSERT INTO `restaurants` (`nameOfRestaurant`, `Data`, `img`) VALUES
('Buffalo Burger', 'Burgers, Fast Food', 'Buffalo Burger.png'),
('CHICKEN FILA', 'Burgers, Fast Food, Sandwiches', 'CHICKEN FILA.png'),
('costa coffee', 'Coffee & Tea, Bakery and Cakes, Beverages', 'costa coffee.png'),
('hardees', 'Burgers, Fast Food, Sandwiches', 'Hardee.png'),
('Kansas Fried Chicken', 'Fast Food.  Fried chicken.  Sandwiches.', 'Kansas Fried Chicken.png'),
('KFC', 'Fast Food. Fried chicken. Sandwiches.', 'kfc.png'),
('macdonald', 'Dessserts. Fast Food. Burger. Sandwiches.', 'macdonald.jpg'),
('Papa Johns Pizza', 'Fast Food. Italian. Pizza.', 'papa-johns.png'),
('pizza master', 'Pizza, Salads', 'pizza master.png'),
('Sayed Hanafy', 'Koshary, Desserts, Oriental', 'sayed hanafy.png'),
('starbucks ', 'Coffee & Tea, Bakery and Cakes, Beverages', 'starbucks.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `User_Name` (`User_Name`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`id`),
  ADD KEY `nameOfRestaurant` (`nameOfRestaurant`);

--
-- Indexes for table `restaurants`
--
ALTER TABLE `restaurants`
  ADD PRIMARY KEY (`nameOfRestaurant`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `food`
--
ALTER TABLE `food`
  ADD CONSTRAINT `food_ibfk_1` FOREIGN KEY (`nameOfRestaurant`) REFERENCES `restaurants` (`nameOfRestaurant`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
