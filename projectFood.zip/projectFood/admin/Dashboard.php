<?php
include "../database/dp_con.php";
if(isset($_GET["action"]))  
 {  
      if($_GET["action"] == "signout")  
      {  

          session_destroy();
          header("location:../index.php");
          exit();
                      
           
 }}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> Tasty.com </title>
    <link rel="stylesheet" href="css/style.css">
    <!-- Boxiocns CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600' rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
    <!--------links for table---------------->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Varela+Round|Open+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <!--------------end links-------------------------->
     <link rel="icon" type="image/png"  href="image/p-pl-icon.png" sizes="200x200">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar close">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">TASTY</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="#">
          <i class='bx bx-grid-alt' ></i>
          <span class="link_name">Dashboard</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="#">Dashboard</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a href="menus.php">
            <i class='bx bx-collection' ></i>
            <span class="link_name">Menu</span>
          </a>
          <ul class="sub-menu blank">
            <li><a class="link_name" href="menus.php">Menu</a></li>
          </ul>   
        </div>
      </li>
      <li>
        <div class="iocn-link">
          <a href="products.php">
            <i class='bx bx-box' ></i>
            <span class="link_name">Products</span>
          </a>
          <ul class="sub-menu blank">
            <li><a class="link_name" href="products.php">Products</a></li>
          </ul>
        </div>
      </li>
      <li>
        <div class="iocn-link">
          <a href="users.php">
            <i class="fa fa-user-circle-o"></i>
            <span class="link_name">Users</span>
          </a>
          <ul class="sub-menu blank">
            <li><a class="link_name" href="users.php">Users</a></li>
          </ul>
        </div>
      </li>
      <li>
    <div class="profile-details">
      <div class="profile-content">
        <img src="image\download.png" alt="profileImg">
      </div>
      <div class="name-job">
        <div class="profile_name">Admin</div>
       
      </div>
      <a href='Dashboard.php?action=signout' > <i class='bx bx-log-out' ></i></a>
    </div>
  </li>
</ul>
  </div>
  <!-------------------------------------------------------content-------------------------------------------------------->
  <section class="home-section">
    <div class="home-content">
      <i class='bx bx-menu' ></i>
      <span class="text">Dashboard</span>
     </div>
    <div class="container">
      <div class="table-wrapper">
          <div class="table-title">
              <div class="row">
                  <div class="col-sm-8"><h2><b>Customer</b></h2></div>
                  
              </div>
          </div>
          <table class="table table-bordered">
              <thead>
                  <tr>
                    <th>id</th>
                      <th>User_Name</th>
                      <th>email</th>
                      <th>Password</th>
                      <th>Phone_number</th>
                  </tr>
                  <tbody>
                  <?php
    
    $sql= "SELECT * from customer";
    $result=$conn-> query($sql);
    if($result-> num_rows > 0){
   while($row = $result-> fetch_assoc() ){
     echo "<tr><td>" .$row['id']. "</td>".
          "<td>" .$row['User_Name']. "</td>".
          "<td>" .$row['email']. "</td>".
          "<td>" .$row['Password'] . "</td>".
          "<td>" .$row['Phone_number'] . "</td>".     
         "<td><a class='edit' title='Edit' data-toggle='tooltip' href='editC.php?id=$row[id]'><i class='material-icons'>". "Edit" . "</i></a></td>".
         "<td><a class='delete' title='Delete' data-toggle='tooltip' href='deleteC.php?id=$row[id]'><i class='material-icons'>" ."Delete". "</i></a></td></tr>".   
             
              "</tbody>";
            }}
              echo"</table>"?> 
      </div>
  </div>    

  <div class="container">
    <div class="table-wrapper">
        <div class="table-title">
            <div class="row">
                <div class="col-sm-8"><h2><b>restaurants</b></h2></div>
               
            </div>
        </div>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>nameOfRestaurant</th>
                    <th>Data </th>
                    <th>img </th>
                </tr>
                <tbody>
                <?php
    
    $sql= "SELECT * from restaurants";
    $result=$conn-> query($sql);
    if($result-> num_rows > 0){
   while($row = $result-> fetch_assoc()){
     echo "<tr><td>" .$row['nameOfRestaurant']. "</td>".
          "<td>" .$row['Data']. "</td>".
          "<td>" .$row['img'] . "</td>"." </thead>".
             
                
         "<td><a class='edit' title='Edit' data-toggle='tooltip' href='editR.php?name=$row[nameOfRestaurant]'><i class='material-icons'>". "Edit" . "</i></a></td>".
         "<td><a class='delete' title='Delete' data-toggle='tooltip' href='deleteR.php?name=$row[nameOfRestaurant]'><i class='material-icons'> " ."Delete". "</i></a></td></tr>".    
              "</tr>".
              "</tbody>";
            }}
              echo"</table>"?>         
    </div>
</div>    
<div class="container">
  <div class="table-wrapper">
      <div class="table-title">
          <div class="row">
              <div class="col-sm-8"><h2><b>food</b></h2></div>
             
          </div>
      </div>
      <table class="table table-bordered">
          <thead>
          <tbody>
              <tr>
                  <th>nameOfFood </th>  
                  <th>nameOfRestaurant </th>
                  <th>Data </th>
              </tr>
              <?php
    
    $sql= "SELECT * from food";
    $result=$conn-> query($sql);
    if($result-> num_rows > 0){
   while($row = $result-> fetch_assoc() ){
     echo "<tr><td>" .$row['nameOfFood']. "</td>".
          "<td>" .$row['nameOfRestaurant']. "</td>".
          "<td>" .$row['Data'] . "</td>"." </thead>".
                
         "<td><a class='edit' title='Edit' data-toggle='tooltip' href='editF.php?id= $row[id]'><i class='material-icons'>". "Edit" . "</i></a></td>".
         "<td><a class='delete' title='Delete' data-toggle='tooltip' href='deleteF.php?id= $row[id]'><i class='material-icons'> " ."Delete". "</i></a></td></tr>".
              
              "</tbody>";
            }}
              echo"</table>"?>   
  </div>
</div>

  </section>

 <!---------------------------------------------------end content------------------------------------------------------------------->
  <script src="js/script.js"></script>

</body>
</html>
