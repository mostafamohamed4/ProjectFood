<?php
include "../database/dp_con.php";
if ( isset($_POST['add'])) {
    $name = $_POST['name'];
    $Description  = $_POST['Description'];
    $image = $_POST['image'];
	
		$sql = "INSERT INTO restaurants (nameOfRestaurant,Data,img)
		VALUES ('$name','$Description','$image')";

          		if ($conn->query($sql) === TRUE) {
                    echo '<script>alert("restaurants  Added")</script>';
                    echo '<script>window.location="menus.php"</script>';
    } else {
        echo '<script>alert("Error")</script>';
        echo '<script>window.location="menus.php"</script>';
    }}