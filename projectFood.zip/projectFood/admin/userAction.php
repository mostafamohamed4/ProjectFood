<?php
include "../database/dp_con.php";
if ( isset($_POST['add'])) {
    $UserName = $_POST['User_Name'];
    $email  = $_POST['email'];
    $Phonenumber = $_POST['Phone_number'];
	$pass   =$_POST['password'];
	$rePassword= $_POST['con_Password'];
	if($pass!= $rePassword){
       
        echo '<script>alert("PassWord dont match")</script>';
        echo '<script>window.location="users.php"</script>';
	}else{
	
		$sql = "INSERT INTO customer (email,Password,Phone_number,User_Name)
		VALUES ('$email','$pass','$Phonenumber','$UserName')";

          		if ($conn->query($sql) === TRUE) {
                    echo '<script>alert("Add users")</script>';
                    echo '<script>window.location="users.php"</script>';
	    
    } else {
        echo '<script>alert("sorry user already exists")</script>';
        echo '<script>window.location="users.php"</script>';

    }}}