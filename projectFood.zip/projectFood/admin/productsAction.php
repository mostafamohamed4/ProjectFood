<?php
include "../database/dp_con.php";
if ( isset($_POST['add'])) {
    $name = $_POST['name'];
    $nameOfRestaurant  = $_POST['nameOfRestaurant'];
    $Price = $_POST['Price'];
	$Description=$_POST['Description'];
    $image=$_POST['image'];
		$sql = "INSERT INTO food (nameOfFood,nameOfRestaurant,countt,Data,img)
		VALUES ('$name','$nameOfRestaurant','$Price','$Description','$image')";

          		if ($conn->query($sql) === TRUE) {
                    echo '<script>alert("Products  Added")</script>';
                    echo '<script>window.location="products.php"</script>';
    } else {
        echo '<script>alert("Error")</script>';
        echo '<script>window.location="products.php"</script>';
    }}