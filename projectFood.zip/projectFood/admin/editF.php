<?php

include "../database/dp_con.php";

$id = $_GET['id']; // get id through query string

$qry = mysqli_query($conn,"select * from food where id='$id'"); // select query

$row = mysqli_fetch_array($qry); // fetch data

if(isset($_POST['update'])) // when click on Update button
{
    $nameOfFood = $_POST['nameOfFood'];
    $nameOfRestaurant  = $_POST['nameOfRestaurant'];
    $Data = $_POST['Data'];
	
    
    $edit = mysqli_query($conn,"update food set nameOfFood='$nameOfFood',nameOfRestaurant='$nameOfRestaurant', 
    Data='$Data' where id='$id'");
	
    if($edit)
    {
        mysqli_close($conn); // Close connection
        header("location:Dashboard.php"); // redirects to all records page
        exit;
    }
    else
    {
        echo "mysqli_error()";
    }    	
}
?>
<html >
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div  class="title">
    <h1 style="padding-left:27%;">Update Data</h1>
    <h3 style="padding-left:34%;">Please fill in this form to Edditing.</h3>
 </div>
 <hr>
<div class="container">


<form method="POST">
  <input type="text" name="nameOfFood" value="<?php echo $row['nameOfFood'] ?>"  Required>
  <input type="text" name="nameOfRestaurant" value="<?php echo $row['nameOfRestaurant'] ?>"   Required>
  <input type="text" name="Data" value="<?php echo $row['Data'] ?>"  Required>
  <input type="submit" name="update" value="update"  style=" margin-left:24%">

</form>
</div>
</body></html>