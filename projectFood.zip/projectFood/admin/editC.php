<?php

include "../database/dp_con.php";

$id = $_GET['id']; // get id through query string

$qry = mysqli_query($conn,"select * from customer where id='$id'"); // select query

$row = mysqli_fetch_array($qry); // fetch data

if(isset($_POST['update'])) // when click on Update button
{
    $UserName = $_POST['User_Name'];
    $email  = $_POST['email'];
    $Phonenumber = $_POST['Phone_number'];
	$pass=$_POST['Password'];
    
    $edit = mysqli_query($conn,"update customer set User_Name='$UserName',email='$email', 
    Phone_number='$Phonenumber',Password ='$pass' where id='$id'");
	
    if($edit)
    {
        mysqli_close($conn); // Close connection
        header("location:Dashboard.php"); // redirects to all records page
        exit;
    }
    else
    {
        echo "mysqli_error()";
    }    	
}
?>
<html >
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div  class="title">
    <h1 style="padding-left:27%;">Update Data</h1>
    <h3 style="padding-left:34%;">Please fill in this form to Edditing.</h3>
 </div>
 <hr>
<div class="container">


<form method="POST">
  <input type="text" name="User_Name" value="<?php echo $row['User_Name'] ?>"  Required>
  <input type="text" name="email" value="<?php echo $row['email'] ?>"   Required>
  <input type="text" name="Password" value="<?php echo $row['Password'] ?>"  Required>
  <input type="text" name="Phone_number" value="<?php echo $row['Phone_number'] ?>" Required>
  <input type="submit" name="update" value="update"  style=" margin-left:24%">

</form>
</div>
</body></html>