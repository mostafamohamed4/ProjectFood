<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title> Tasty.com </title>
    <link rel="stylesheet" href="css/style.css">
    <!-- Boxiocns CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" type="image/png"  href="image/p-pl-icon.png" sizes="200x200">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar close">
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">TASTY</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href="Dashboard.php">
          <i class='bx bx-grid-alt' ></i>
          <span class="link_name">Dashboard</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href="Dashboard.php">Dashboard</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a href="#">
            <i class='bx bx-collection' ></i>
            <span class="link_name">Menu</span>
          </a>
          <ul class="sub-menu blank">
            <li><a class="link_name" href="#">Menu</a></li>
          </ul> 
        </div>
      </li>
      <li>
        <div class="iocn-link">
          <a href="products.php">
            <i class='bx bx-box' ></i>
            <span class="link_name">Products</span>
          </a>
          <ul class="sub-menu blank">
            <li><a class="link_name" href="products.php">Products</a></li>
          </ul>
        </div>
      </li>
      <li>
        <div class="iocn-link">
          <a href="users.php">
            <i class="fa fa-user-circle-o"></i>
            <span class="link_name">Users</span>
          </a>
          <ul class="sub-menu blank">
            <li><a class="link_name" href="users.php">Users</a></li>
          </ul>
        </div>
      </li>
      <li>
    <div class="profile-details">
      <div class="profile-content">
        <img src="image/download.png" alt="profileImg">
      </div>
      <div class="name-job">
        <div class="profile_name">Admin</div>
       
      </div>
      <a href='Dashboard.php?action=signout' > <i class='bx bx-log-out' ></i></a>
    </div>
  </li>
</ul>
  </div>
  <!-------------------------------------------------------Menu settings-------------------------------------------------------->
  <section class="home-section"style="height: 100vh !important;">
    <div class="home-content">
      <i class='bx bx-menu' ></i>
      <span class="text">Menu</span>
    </div>  
    <div class="main-block">
      <h1>Menu settings</h1>
      <form action="menusAction.php" method="POST">
        <div class="info">
          <input class="fname" type="text" name="name" placeholder="Menu name">
          <div class="form-group green-border-focus">
            <label for="exampleFormControlTextarea5">Description</label><br>
            <textarea  name="Description" class="form-control" id="exampleFormControlTextarea5" rows="10" cols="77" placeholder="message" style="width: 475px;"></textarea>          </div>
          <label for="exampleFormControlTextarea5">Product Image</label><br>
          <input type="file" class="custom-file-input" style="background: #fff;" name="image">
        </div>
        <br><br>
    
    <div>
        <button values="add" name="add" class="button"style="margin-top: -336px;">Add</button>
        
      </div>
      </form>
    </div>
  </section>
<!---------------------------------------------------end Menu settings------------------------------------------------------------------->
  <script src="js/script.js"></script>

</body>
</html>
