<?php
include "../database/dp_con.php";
session_start();
if(isset($_GET["action"]))  
 {  
      if($_GET["action"] == "signout")  
      {  

          session_destroy();
          header("location:../index.php");
          exit();
                      
           
 }}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" type="image/png"  href="image/p-pl-icon.png" sizes="200x200">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <!-- font awesome cdn link  -->
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<!-- custom css file link  -->
<link rel="stylesheet" href="css/style.css">

</head>
<body>
<!-- header section starts      -->

<header class="header">

  <a href="#" class="logo"> TASTY </a>

  <nav class="navbar">
      <a href="#home">home</a>
      <a href="#All Restaurants">All Restaurants</a>
      <a href='payment.php?action=signout'>log out</a>
   
  </nav>

  <div class="icons">
      <div class="fas fa-bars" id="menu-btn"></div>
      
   
     
  </div>

  <form action="" class="search-form">
      <input type="search" id="search-box" placeholder="search here...">
      <label for="search-box" class="fas fa-search"></label>
  </form>

  


</header>
<div class="container">
<div class="col-25">
    
<div class="container-card">
<h4>Cart <span class="price" style="color:black"><i class="fa fa-shopping-cart"></i> </span></h4>
<!-- header section ends-->
<?php
        	$total=0;
        	 foreach($_SESSION["shopping_cart"] as $keys => $values)  
      {  
      	  
      	?>


  
      
      <p><?php echo $values["item_name"] . " x " . $values["item_Qty"] ; ?> <span class="price">EGP:<?php echo number_format($values["item_Qty"] * $values["item_price"]); ?></span></p>
      <hr>
      <?php
              	$total = $total + ($values["item_Qty"] * $values["item_price"]);
              }?>
      <p>Total <span class="price" style="color:black"><b>EGP:<?php echo number_format($total, 2); ?></b></span></p>
    </div>
  </div>
  <div class="card-container">

      <div class="front">
          <div class="image">
              <img src="image/chip.png" alt="">
              <img src="image/visa.png" alt="">
          </div>
          <div class="card-number-box">################</div>
          <div class="flexbox">
              <div class="box">
                  <span>card holder</span>
                  <div class="card-holder-name">full name</div>
              </div>
              <div class="box">
                  <span>expires</span>
                  <div class="expiration">
                      <span class="exp-month">mm</span>
                      <span class="exp-year">yy</span>
                  </div>
              </div>
          </div>
      </div>

      <div class="back">
          <div class="stripe"></div>
          <div class="box">
              <span>cvv</span>
              <div class="cvv-box"></div>
              <img src="image/visa.png" alt="">
          </div>
      </div>

  </div>

  <form action="">
      <div class="inputBox">
          <span>card number</span>
          <input type="text" maxlength="16" class="card-number-input">
      </div>
      <div class="inputBox">
          <span>card holder</span>
          <input type="text" class="card-holder-input">
      </div>
      <div class="flexbox">
          <div class="inputBox">
              <span>expiration mm</span>
              <select name="" id="" class="month-input">
                  <option value="month" selected disabled>month</option>
                  <option value="01">01</option>
                  <option value="02">02</option>
                  <option value="03">03</option>
                  <option value="04">04</option>
                  <option value="05">05</option>
                  <option value="06">06</option>
                  <option value="07">07</option>
                  <option value="08">08</option>
                  <option value="09">09</option>
                  <option value="10">10</option>
                  <option value="11">11</option>
                  <option value="12">12</option>
              </select>
          </div>
          <div class="inputBox">
              <span>expiration yy</span>
              <select name="" id="" class="year-input">
                  <option value="year" selected disabled>year</option>
                  <option value="2021">2021</option>
                  <option value="2022">2022</option>
                  <option value="2023">2023</option>
                  <option value="2024">2024</option>
                  <option value="2025">2025</option>
                  <option value="2026">2026</option>
                  <option value="2027">2027</option>
                  <option value="2028">2028</option>
                  <option value="2029">2029</option>
                  <option value="2030">2030</option>
              </select>
          </div>
          <div class="inputBox">
              <span>cvv</span>
              <input type="text" maxlength="4" class="cvv-input">
          </div>
      </div>
      <input type="submit" value="submit" class="submit-btn">
  </form>

</div>    
 <!-- footer section starts  -->

<section class="footer">

  <div class="box-container">

      <div class="box">
          <h3>locations</h3>
          <a href="#">nasr city</a>
          <a href="#">cairo</a>
          <a href="#">m3adiii</a>
          <a href="#">USA</a>
          <a href="#">alzmaalk</a>
      </div>

      <div class="box">
          <h3>quick links</h3>
          <a href="#">home</a>
          <a href="#">dishes</a>
          <a href="#">about</a>
          <a href="#">menu</a>
          <a href="#">reivew</a>
          <a href="#">order</a>
      </div>

      <div class="box">
          <h3>contact info</h3>
          <a href="#">nouran</a>
          <a href="#">mostafa</a>
          <a href="#">mostafa@gmail.com</a>
          <a href="#">nouran@gmail.com</a>
          <a href="#">mumbai, india - 400104</a>
      </div>

      <div class="box">
          <h3>follow us</h3>
          <a href="#">facebook</a>
          <a href="#">twitter</a>
          <a href="#">instagram</a>
          <a href="#">linkedin</a>
      </div>

  </div>

</section>

<!-- footer section ends --> 





<script>

document.querySelector('.card-number-input').oninput = () =>{
  document.querySelector('.card-number-box').innerText = document.querySelector('.card-number-input').value;
}

document.querySelector('.card-holder-input').oninput = () =>{
  document.querySelector('.card-holder-name').innerText = document.querySelector('.card-holder-input').value;
}

document.querySelector('.month-input').oninput = () =>{
  document.querySelector('.exp-month').innerText = document.querySelector('.month-input').value;
}

document.querySelector('.year-input').oninput = () =>{
  document.querySelector('.exp-year').innerText = document.querySelector('.year-input').value;
}

document.querySelector('.cvv-input').onmouseenter = () =>{
  document.querySelector('.front').style.transform = 'perspective(1000px) rotateY(-180deg)';
  document.querySelector('.back').style.transform = 'perspective(1000px) rotateY(0deg)';
}

document.querySelector('.cvv-input').onmouseleave = () =>{
  document.querySelector('.front').style.transform = 'perspective(1000px) rotateY(0deg)';
  document.querySelector('.back').style.transform = 'perspective(1000px) rotateY(180deg)';
}

document.querySelector('.cvv-input').oninput = () =>{
  document.querySelector('.cvv-box').innerText = document.querySelector('.cvv-input').value;
}

</script>
<script>
  /*new navbar*/
let searchForm = document.querySelector('.search-form');

document.querySelector('#search-btn').onclick = () =>{
    searchForm.classList.toggle('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}

let shoppingCart = document.querySelector('.shopping-cart');

document.querySelector('#cart-btn').onclick = () =>{
    shoppingCart.classList.toggle('active');
    searchForm.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}

let navbar = document.querySelector('.navbar');

document.querySelector('#menu-btn').onclick = () =>{
    navbar.classList.toggle('active');
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
}

window.onscroll = () =>{
    searchForm.classList.remove('active');
    shoppingCart.classList.remove('active');
    loginForm.classList.remove('active');
    navbar.classList.remove('active');
}
/*end new*/
</script>
</body>
</html>
