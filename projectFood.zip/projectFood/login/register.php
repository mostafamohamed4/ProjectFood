<?php
include "dp_con.php";
session_start();

if ( isset($_POST['register'])) {
    $UserName = $_POST['User_Name'];
    $email  = $_POST['email'];
    $Phonenumber = $_POST['Phone_number'];
	$pass   =$_POST['password'];
	$rePassword= $_POST['con_Password'];
	if($pass!= $rePassword){
        header("Location:index.php?error=PassWord don't match");
	}else{
	
		$sql = "INSERT INTO customer (email,Password,Phone_number,User_Name)
		VALUES ('$email','$pass','$Phonenumber','$UserName')";

          		if ($conn->query($sql) === TRUE) {
			
  	header("Location: index.php?error=registertion done") ;
	    exit();
    } else {
	header("Location: index.php?error=sorry user already exists");
	    exit();
    }}}