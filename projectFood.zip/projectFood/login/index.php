<!DOCTYPE html>
<html>
<head>
<title>Tasty.com</title>
<link rel="stylesheet" href="css/login.css">
</head>
    <body>
    
<div class="main">
    <div class="navbar">
        <div class="icon">
            <h2 class="logo">TASTY</h2>
        </div>
        <div class="menu">
            <ul>
            <li><a href="../index.php">Home</a></li>
                <li><a href="../menu/MENU.php">All Restaurants</a></li>
                
            </ul>
        </div>
        
    </div>
    <div class="content">
        <h1>Discover &<br><span>Order the food</span><br>you love.</h1> 
        <p class="par">Create an account<br>And explore TASTY </p>
    <!---<button class="cn"><a href="#">Join Us</a></button> --->
    </div>
    <div class="hero">     
    <div class="form">
        <div class="buuton-box">
        <div id="bttn"></div>
        <button type="button" class="toggle-bttn" onclick="login()">Login</button>
        <button type="button" class="toggle-bttn" onclick="register()">Register</button>
        </div>

   <!-- login form start------->
        <form action="login.php" method="post"  id="login" class="input-group">
            <?php if(isset($_GET['error'])){
                echo "<p class='error'>" . $_GET['error'] . "</p>";
            }?>
        <input type="text" name="usernane" placeholder="Enter username"required>
        <input type="password" name="passowrd"  placeholder="Enter Password Here"required>
        <button  class="btnn" name='login'>Login</button>
        <P class="links">Don't have an account<br>
        <a href="#">sign up </a>here</a></p>
    </form>
    <!-- login form end------->

     <!-- register form start------->
        <form action="register.php"  method="post"  id="register" class="input-group"> 
        <?php if(isset($_GET['error'])){
                echo "<p class='error'>" . $_GET['error'] . "</p>";
            }?>
        <input type="text" name="User_Name"  placeholder="user name"required> 
        <input type="email" name="email" placeholder="Enter Email Here"required>
        <input type="number" name=" Phone_number"  placeholder="phone number" required>
        <input type="password" name="password"  placeholder="Enter Password Here"required>
        <input type="password" name="con_Password"  placeholder="Enter Password Here" required>
        <button class="btnn" name='register'>sign up</button>
       <!--- <p class="liw">Login with</p>-->
    </form>
    </div>
    </div>


<script>
(function(doc){
  var scriptElm = doc.scripts[doc.scripts.length - 1];
  var warn = ['[ionicons] Deprecated script, please remove: ' + scriptElm.outerHTML];

  warn.push('To improve performance it is recommended to set the differential scripts in the head as follows:')

  var parts = scriptElm.src.split('/');
  parts.pop();
  parts.push('ionicons');
  var url = parts.join('/');

  var scriptElm = doc.createElement('script');
  scriptElm.setAttribute('type', 'module');
  scriptElm.src = url + '/ionicons.esm.js';
  warn.push(scriptElm.outerHTML);
  scriptElm.setAttribute('data-stencil-namespace', 'ionicons');
  doc.head.appendChild(scriptElm);

  
  scriptElm = doc.createElement('script');
  scriptElm.setAttribute('nomodule', '');
  scriptElm.src = url + '/ionicons.js';
  warn.push(scriptElm.outerHTML);
  scriptElm.setAttribute('data-stencil-namespace', 'ionicons');
  doc.head.appendChild(scriptElm)
  
  console.warn(warn.join('\n'));

})(document);

var x= document.getElementById("login");
    var y= document.getElementById("register");
    var z= document.getElementById("bttn");
    function register () {
        x.style.left="-900px";
        y.style.left="-540px";
        z.style.left="110px";
    }
    function login () {
        x.style.left="-545px";
        y.style.left="450px";
        z.style.left="0";
    }
</script>
<!----------------------------------------------------------------------------->
    </body>
</html> 