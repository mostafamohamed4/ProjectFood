<?php
include "dp_con.php";
session_start();
if (isset($_POST['login']) ) {
$uname =$_POST['usernane'];
$pass=$_POST['passowrd'];
if(preg_match("/admin/", $uname)) {
		
  $sql="SELECT * FROM admin where User_Name='$uname' and Password='$pass' ";
  $result=mysqli_query($conn, $sql);
  if (mysqli_num_rows($result)==1) {
    $rows=mysqli_fetch_assoc($result);
    if ($rows['User_Name']==$uname && $rows['Password']==$pass) {
       header("Location:../admin/Dashboard.php");
       exit();
    }
  }
  }else{
  $sql="SELECT * FROM customer where User_Name='$uname' and Password='$pass'";
    $result=mysqli_query($conn,$sql);
    $row=mysqli_fetch_assoc($result);
    if ($row['User_Name']==$uname && $row['Password']==$pass ) {
        $_SESSION["username_customer"]=$uname;
        $_SESSION["login"]=true;
        header("Location:../index.php");
        exit();

}else {
    header("Location:index.php?error=Incorect username or passord!");
    exit();
}
}
}
