<?php
session_start();
include "../database/dp_con.php";
include "add_to_cartAction.php";
if(isset($_GET["action"]))  
 {  
      if($_GET["action"] == "signout")  
      {  

          session_destroy();
          header("location:menu2.php");
          exit();
                      
           
 }}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png"  href="images/p-pl-icon.png" sizes="200x200">
    <!----- start header here-->       
<link href="css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="bootstrap.min.js"></script>
<script src="js/jquery.min.js"></script>
<link rel="stylesheet" href="css/animate.min.css">
<link rel="stylesheet" href="css/swiper-bundle.min.css">
<link rel="stylesheet" href="css/owl.carousel.min.css">
<link rel="stylesheet" href="css/owl.theme.default.css">
<script src="js/owl.carousel.js"></script>
  <!----- end header here-->
    <title>tasty.com</title>
<style>
.menuu{
    width: 400px;
    float: left;
    height: 70px;
}
ul{
    display: flex;
    justify-content: center;
    align-items: center;
   width: max-content;
}
ul li{
    list-style: none;
    margin-left: 92px;
    margin-top: 20px;
    font-size: 21px;
}
ul li a{
    text-decoration: none;
    color:#666;
    font-family: arial; 
    font-weight: bold;
    transition: 0.4s ease-in-out;
}
ul li a:hover{
    color: #ff7200;
}

</style>
   

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">
    <script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myDIV li").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>
</head>
<body>
    
<!-- header section starts      -->

<header class="header">

    <a href="#" class="logo"> TASTY </a>

    <nav class="navbar">
        <a href="../index.php">home</a>
        <a href="../menu/MENU.php">All Restaurants</a>
        <?php
        if (isset($_SESSION["login"])) {
            echo "<a href='menu2.php?action=signout'>log out</a>";
        }else {
          
            echo "<a href='../login/index.php'> Join Us</a> ";
        }
        ?>
       
    </nav>

    <div class="icons">
        <div class="fas fa-bars" id="menu-btn"></div>
        <div class="fas fa-search" id="search-btn"></div>
        <div class="fas fa-shopping-cart" id="cart-btn"></div>
       
    </div>

    <form action="" class="search-form">
        <input type="search" id="myInput" placeholder="search here...">
        <label for="search-box" class="fas fa-search"></label>
    </form>
    <div class="shopping-cart">
    <form action="../paymentPage/payment.php?" method="post">
<?php 

if(!empty($_SESSION["shopping_cart"]))  
  {  
    $total = 0;  
   foreach($_SESSION["shopping_cart"] as $keys => $values)  
   {  
    $id= $values["item_id"];             
    $query = "SELECT * FROM food WHERE id='$id'";
    $result = mysqli_query($conn,$query);
    if (mysqli_num_rows($result)>0) {
    $row = mysqli_fetch_array($result);
    ?>  
  
        <div class="box">

           <a href="menu2.php?name=<?php echo $row['nameOfRestaurant']; ?>&action=delete&id=<?php echo $values["item_id"]; ?> " > <i class="fas fa-trash"></i></a>
            <img src="../menuImages/<?php echo $values["image"]; ?>" alt="">
            <div class="content">
                <h3><?php echo $values["item_name"]; ?></h3>
                <span class="price"><?php echo $values["item_price"]; ?></span>
                <span class="quantity">qty : <?php echo $values["item_Qty"]; ?></span>
            </div>
        </div>
        <?php  }
             $total = $total + ($values["item_Qty"] * $values["item_price"]);  
                             }  
                        ?>  
        <div class="total"> total : <?php echo number_format($total, 2); ?> </div>
          
        <?php if (isset($_SESSION['login'])) {
              echo " <input type='submit' name='Confirm' class='btn-checkout' value='checkout'> </form>";

            }else {?>
            </form>
            <button  class="btn-checkout" onclick="alert('Please login First')" >checkout</button>
                 
             
          <?php  }?>
        </div>
        <?php  
      }  
                        ?> 
    
</header>

<!-- header section ends-->


<!-- home section starts  -->
<!-------------------------------------header here------------------------------------------------------------->
<?php
$name= $_GET['name']; 

    $query = "SELECT * FROM food where nameOfRestaurant='$name'";
    $result = mysqli_query($conn,$query);
    if (mysqli_num_rows($result)>0) {
    $row = mysqli_fetch_array($result)
        ?>
<header>
    <div class="owl-carousel owl-theme">
        <div class="item">
            <img src="../Pictures/<?php echo $row['im1'] ?>" >
      
                <div class="container">
                    <div class="header-content">
                        <div class="line"></div>
                      
               
                </div>
             </div>
        </div>                    
        <div class="item">
            <img src="../Pictures/<?php echo $row['im2'] ?>" >
        
                <div class="container">
                    <div class="header-content">
                        <div class="line animated bounceInLeft"></div>
                   
              
                </div>
             </div>
        </div>                
        <div class="item">
            <img src="../Pictures/<?php echo $row['im3'] ?>" >
           
                <div class="container">
                    <div class="header-content">
                        <div class="line animated bounceInLeft"></div>
                     
                    </div>
                </div>
             </div>
        </div>
    </div>
    </header>
 <?php }?>
<!-- home section ends -->


<!-- menu section starts  -->

<section class="menu" id="menu">

    <h3 class="sub-heading"> our menu </h3>
    <h1 class="heading"> today's speciality </h1>

    <div class="box-container" id="myDIV">
    <?php
 

    $query = "SELECT * FROM food where nameOfRestaurant='$name'";
    $result = mysqli_query($conn,$query);
    if (mysqli_num_rows($result)>0) {
        while ($row = mysqli_fetch_array($result)) {
    ?>
    <li>
  <form method="post" action="menu2.php?name=<?php echo $name;?>&action=add&id=<?php echo $row["id"]; ?>">

        <div class="box">
            <div class="image">
                <img src="../menuImages/<?php echo $row['img'] ;?>" alt="">
        
            </div>
            <div class="content">
                <h3> <?php echo $row["nameOfFood"]; ?> </h3>

                <input type="hidden" name="name" value="<?php echo $row["nameOfFood"]; ?>" />  
                <input type="hidden" name="price" value="<?php echo $row["countt"]; ?>" /> 
                <input type="hidden" name="image" value="<?php echo $row["img"]; ?>" /> 

                <p><?php echo $row['Data'] ;?></p>
                <button  type="submit" name="add_to_cart" value="add_to_cart" class="btn">add to cart</button>
                <span class="price"><?php echo $row['countt'] . "EGP" ;?></span>
              
                <h1>Qty:<input type="number" name="Qty"  class="tex" min="1" value="1" ></h1>    
       
            </div>
        </div>
        </li>
        </form>

        <?php }}?>
    </div>

</section>

<!-- menu section ends -->

<!-- review section starts  -->

<section class="review" id="review">

    <h3 class="sub-heading"> customer's review </h3>
    <h1 class="heading"> what they say </h1>

    <div class="swiper-container review-slider">

        <div class="swiper-wrapper">
        <?php
    $query = "SELECT * FROM comment where nameOfRestaurant='$name'";
    $result = mysqli_query($conn,$query);
    if (mysqli_num_rows($result)>0) {
        while ($row = mysqli_fetch_array($result)) {
    ?>
            <div class="swiper-slide slide">
                <i class="fas fa-quote-right"></i>
                <div class="user">
                    <img src="images/mostafa ma.jpeg" alt="">
                    <div class="user-info">
                        <h3><?php  echo $row['customerName'];?></h3>
                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star-half-alt"></i>
                        </div>
                    </div>
                </div>
                <p><?php  echo $row['comment'];?></p>
            </div>

           
<?php }}?>
           

           

        </div>

    </div>
    
</section>

<!-- review section ends -->

<!-- order section starts  -->

<section class="order" id="order">

    <h1 class="heeading"> <span>comment</span> here </h1>

    <div class="row">
        
        <div class="image">
            <img src="images/order-img.jpg" alt="">
        </div>
        <?php
   $query = "SELECT * FROM food where nameOfRestaurant='$name'";
   $result = mysqli_query($conn,$query);
   if (mysqli_num_rows($result)>0) {
    $row = mysqli_fetch_array($result) 
    
    ?>
        <form action="comment.php?id=<?php echo $row["id"];?>" method="post">

            <div class="inputBox">
                <input type="text" placeholder="name" name='name'>
            </div>
            
            <textarea placeholder="put your comment here ......" name="com"  cols="30" rows="10"></textarea>

            <input type="submit" name="comment" value="comment" class="btn-review">

        </form>
      <?php }?>
    </div>

</section>

<!-- order section ends -->

<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>locations</h3>
            <a href="#">nasr city</a>
            <a href="#">cairo</a>
            <a href="#">m3adiii</a>
            <a href="#">USA</a>
            <a href="#">alzmaalk</a>
        </div>

        <div class="box">
            <h3>quick links</h3>
            <a href="#">home</a>
            <a href="#">dishes</a>
            <a href="#">about</a>
            <a href="#">menu</a>
            <a href="#">reivew</a>
            <a href="#">order</a>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <a href="#">nouran</a>
            <a href="#">mostafa</a>
            <a href="#">mostafa@gmail.com</a>
            <a href="#">nouran@gmail.com</a>
            <a href="#">mumbai, india - 400104</a>
        </div>

        <div class="box">
            <h3>follow us</h3>
            <a href="#">facebook</a>
            <a href="#">twitter</a>
            <a href="#">instagram</a>
            <a href="#">linkedin</a>
        </div>

    </div>

</section>

<!-- footer section ends -->

<!-- loader part  -->
<div class="loader-container">
    <img src="images/loader.gif" alt="">
</div>


<script src="js/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>
<script>
    $('.owl-carousel').owlCarousel({
     loop:true,
     margin:10,
     dots:false,
     nav:true,
     mouseDrag:false,
     autoplay:true,
     animateOut: 'slideOutUp',
     responsive:{
         0:{
             items:1
         },
         600:{
             items:1
         },
         1000:{
             items:1
         }
     }
 });   
     </script>
</body>
</html>