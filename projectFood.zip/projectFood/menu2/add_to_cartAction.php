<?php
include "../database/dp_con.php";

if (isset($_POST["add_to_cart"]))
 {
  $id= $_GET["id"];
  $query = "SELECT * FROM food WHERE id='$id'";
  $result = mysqli_query($conn,$query);
  if (mysqli_num_rows($result)>0) {
  $row = mysqli_fetch_array($result);
  $nameOfRestaurant=$row['nameOfRestaurant'];
  }
  if (isset($_SESSION["shopping_cart"]))
   {
    $item_array_id=array_column($_SESSION["shopping_cart"], "item_id");
    if (!in_array($_GET["id"], $item_array_id)) {
     $count=count($_SESSION["shopping_cart"]);
      $item_array = array(
      'item_id' => $_GET["id"] , 
      'item_name' => $_POST["name"] , 
      'item_price' => $_POST["price"] ,
      'item_Qty' => $_POST["Qty"],
      'image' =>   $_POST["image"]
    );
      $_SESSION["shopping_cart"][$count]=$item_array ;
      echo '<script>alert("Item  Added")</script>';
      echo '<script>window.location="menu2.php?name="'.$nameOfRestaurant.'</script>';

    }else{
      echo '<script>alert("Item Already Added")</script>';
      echo '<script>window.location="menu2.php?name="'.$nameOfRestaurant.'</script>';
    }
  }
  else{
    $item_array = array(
      'item_id' => $_GET["id"] , 
      'item_name' => $_POST["name"] , 
      'item_price' => $_POST["price"] ,
      'item_Qty' => $_POST["Qty"] ,
      'image' =>   $_POST["image"]
    );
    $_SESSION["shopping_cart"][0]=$item_array ;
  }
}
if(isset($_GET["action"]))  
 {  
      if($_GET["action"] == "delete")  
      {  
           foreach($_SESSION["shopping_cart"] as $keys => $values)  
           {  
                if($values["item_id"] == $_GET["id"])  
                {   $id= $_GET["id"];
                  $query = "SELECT * FROM food WHERE id='$id'";
                  $result = mysqli_query($conn,$query);
                  if (mysqli_num_rows($result)>0) {
                  $row = mysqli_fetch_array($result);
                     unset($_SESSION["shopping_cart"][$keys]);  
                     echo '<script>alert("Item Removed")</script>';  
                     echo '<script>window.location="menu2.php?name="'.$row['nameOfRestaurant'].'</script>';
                 } }  
           }  
      }  
 }
 