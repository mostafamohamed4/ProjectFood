<?php
include "../database/dp_con.php";
$id= $_GET["id"];
$query = "SELECT * FROM food WHERE id='$id'";
$result = mysqli_query($conn,$query);
if (mysqli_num_rows($result)>0) {
$row = mysqli_fetch_array($result);
$nameOfRestaurant=$row['nameOfRestaurant'];
}
if(isset($_POST['comment'])){
$name = $_POST['name'];
$comment=$_POST['com'];
$sql = "INSERT INTO comment (customerName,comment,nameOfRestaurant)
		VALUES ('$name','$comment','$nameOfRestaurant')";
        if ($conn->query($sql) === TRUE) {
			
          echo '<script>alert("Thank you for yor comment")</script>';
          echo '<script>window.location="menu2.php?name='.$nameOfRestaurant.'"</script>';
          
          }else{

            echo '<script>alert("Error")</script>';
            echo '<script>window.location="menu2.php?name='.$nameOfRestaurant.'"</script>';
          }
}